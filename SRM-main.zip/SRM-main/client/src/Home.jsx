import React, { useState, useEffect } from "react";


export default function Home()
{
    fetch
    return(
        <>

        <div className="mx-auto">
            <input className="input input-bordered h-32 w-96"></input>
        </div>
        </>
    )
}